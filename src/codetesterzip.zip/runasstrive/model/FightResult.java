package runasstrive.model;

public enum FightResult {
    GAME_OVER, GAME_WON, STAGE_CLEARED, LEVEL_CLEARED, CONTINUE
}
